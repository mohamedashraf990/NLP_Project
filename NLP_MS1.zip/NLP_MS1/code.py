import re    # for regular expressions 
import nltk  # for text manipulation 
import warnings 
import numpy as np 
import pandas as pd 
import seaborn as sns 
import matplotlib.pyplot as plt  
from nltk.stem.porter import * 
from sklearn.feature_extraction.text import TfidfVectorizer 
# from wordcloud import WordCloud

stemmer = PorterStemmer() 
pd.set_option("display.max_colwidth", 200) 
warnings.filterwarnings("ignore", category=DeprecationWarning) 
test  = pd.read_csv('input/test_tweets_anuFYb8.csv') 
train = pd.read_csv('input/train_E6oV3lV.csv')


print(train.shape)
print(train.head(10))

print(test.shape)
print(test.head(10))
print(train["label"].value_counts())
plt.hist(train.tweet.str.len(), bins=20, label='train')
plt.hist(test.tweet.str.len(), bins=20, label='test')
plt.legend()
plt.show()

tweets_df = train.append(test, ignore_index=True, sort=True)
print(tweets_df.shape)
print(tweets_df.dtypes)
print(tweets_df.head(10))


def remove_pattern(input_txt, pattern):
    r = re.findall(pattern, input_txt)
    for i in r:
        input_txt = re.sub(i, '', input_txt)
        # print(input_txt)
    return input_txt


# Remove usernames from tweets
tweets_df['clean_tweet'] = np.vectorize(remove_pattern)(tweets_df['tweet'], "@[\w]*") 

# Remove non-alphabetic characters and short words from tweets
tweets_df['clean_tweet'] = tweets_df.clean_tweet.str.replace("[^a-zA-Z#]", " ")
tweets_df['clean_tweet'] = tweets_df.clean_tweet.apply(lambda x: ' '.join([w for w in x.split() if len(w) > 3]))

# Tokenize and stem words in tweets
tokenized_tweet = tweets_df['clean_tweet'].apply(lambda x: x.split())
tokenized_tweet = tokenized_tweet.apply(lambda x: [stemmer.stem(i) for i in x])

# Join stemmed words in each tweet
for i in range(len(tokenized_tweet)):
    tokenized_tweet[i] = ' '.join(tokenized_tweet[i])    
tweets_df['clean_tweet'] = tokenized_tweet


joined_words = ' '.join([text for text in tweets_df['clean_tweet']])

def extract_hashtags(tweets):
    hashtags = []
    for tweet in tweets:
        ht = re.findall(r"#(\w+)", tweet)
        hashtags.append(ht)
    return hashtags

regular_tweet_hashtags = extract_hashtags(tweets_df[tweets_df['label'] == 0]['clean_tweet'])
negative_tweet_hashtags = extract_hashtags(tweets_df[tweets_df['label'] == 1]['clean_tweet'])
regular_tweet_hashtags = sum(regular_tweet_hashtags, [])
negative_tweet_hashtags = sum(negative_tweet_hashtags, [])
print(regular_tweet_hashtags)
print(negative_tweet_hashtags)

regular_tweet_hashtags_freq = nltk.FreqDist(regular_tweet_hashtags)
top_hashtags_df = pd.DataFrame({
    'Hashtag': list(regular_tweet_hashtags_freq.keys()),
    'Count': list(regular_tweet_hashtags_freq.values())
}).nlargest(columns='Count', n=20)

plt.figure(figsize=(20, 5))
ax = sns.barplot(data=top_hashtags_df, x='Hashtag', y='Count')
ax.set(ylabel='Count')
plt.show()

negative_tweet_hashtags_freq = nltk.FreqDist(negative_tweet_hashtags)
top_hashtags_df = pd.DataFrame({
    'Hashtag': list(negative_tweet_hashtags_freq.keys()),
    'Count': list(negative_tweet_hashtags_freq.values())
}).nlargest(columns='Count', n=20)

plt.figure(figsize=(20, 5))
ax = sns.barplot(data=top_hashtags_df, x='Hashtag', y='Count')
ax.set(ylabel='Count')
plt.show()

# TFIDF
tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(tweets_df['clean_tweet'])
print(f"TF-IDF matrix shape: {tfidf_matrix.shape}")





