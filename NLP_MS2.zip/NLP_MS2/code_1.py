import re    # for regular expressions 
import nltk  # for text manipulation 
import warnings 
import numpy as np 
import pandas as pd 
import seaborn as sns 
import matplotlib.pyplot as plt  
from nltk.stem.porter import * 
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer 
import gensim
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn import svm

import xgboost as xgb
from xgboost import XGBClassifier
# from wordcloud import WordCloud

stemmer = PorterStemmer() 
pd.set_option("display.max_colwidth", 200) 
warnings.filterwarnings("ignore", category=DeprecationWarning) 
test  = pd.read_csv('input/test_tweets_anuFYb8.csv') 
train = pd.read_csv('input/train_E6oV3lV.csv')


# print(train.shape)
# print(train.head(10))

# print(test.shape)
# print(test.head(10))
# print(train["label"].value_counts())
plt.hist(train.tweet.str.len(), bins=20, label='train')
plt.hist(test.tweet.str.len(), bins=20, label='test')
plt.legend()
plt.show()

tweets_df = train.append(test, ignore_index=True, sort=True)
# print(tweets_df.shape)
# print(tweets_df.dtypes)
# print(tweets_df.head(10))


def remove_pattern(input_txt, pattern):
    r = re.findall(pattern, input_txt)
    for i in r:
        input_txt = re.sub(i, '', input_txt)
        # print(input_txt)
    return input_txt


# Remove usernames from tweets
tweets_df['clean_tweet'] = np.vectorize(remove_pattern)(tweets_df['tweet'], "@[\w]*") 

# Remove non-alphabetic characters and short words from tweets
tweets_df['clean_tweet'] = tweets_df.clean_tweet.str.replace("[^a-zA-Z#]", " ")
tweets_df['clean_tweet'] = tweets_df.clean_tweet.apply(lambda x: ' '.join([w for w in x.split() if len(w) > 3]))

# Tokenize and stem words in tweets
tokenized_tweet = tweets_df['clean_tweet'].apply(lambda x: x.split())
tokenized_tweet = tokenized_tweet.apply(lambda x: [stemmer.stem(i) for i in x])

# Join stemmed words in each tweet
for i in range(len(tokenized_tweet)):
    tokenized_tweet[i] = ' '.join(tokenized_tweet[i])    
tweets_df['clean_tweet'] = tokenized_tweet


joined_words = ' '.join([text for text in tweets_df['clean_tweet']])

def extract_hashtags(tweets):
    hashtags = []
    for tweet in tweets:
        ht = re.findall(r"#(\w+)", tweet)
        hashtags.append(ht)
    return hashtags

regular_tweet_hashtags = extract_hashtags(tweets_df[tweets_df['label'] == 0]['clean_tweet'])
negative_tweet_hashtags = extract_hashtags(tweets_df[tweets_df['label'] == 1]['clean_tweet'])
regular_tweet_hashtags = sum(regular_tweet_hashtags, [])
negative_tweet_hashtags = sum(negative_tweet_hashtags, [])
# print(regular_tweet_hashtags)
# print(negative_tweet_hashtags)

regular_tweet_hashtags_freq = nltk.FreqDist(regular_tweet_hashtags)
top_hashtags_df = pd.DataFrame({
    'Hashtag': list(regular_tweet_hashtags_freq.keys()),
    'Count': list(regular_tweet_hashtags_freq.values())
}).nlargest(columns='Count', n=20)

plt.figure(figsize=(20, 5))
ax = sns.barplot(data=top_hashtags_df, x='Hashtag', y='Count')
ax.set(ylabel='Count')
plt.show()

negative_tweet_hashtags_freq = nltk.FreqDist(negative_tweet_hashtags)
top_hashtags_df = pd.DataFrame({
    'Hashtag': list(negative_tweet_hashtags_freq.keys()),
    'Count': list(negative_tweet_hashtags_freq.values())
}).nlargest(columns='Count', n=20)

plt.figure(figsize=(20, 5))
ax = sns.barplot(data=top_hashtags_df, x='Hashtag', y='Count')
ax.set(ylabel='Count')
plt.show()

# TFIDF

# print(f"TF-IDF matrix shape: {tfidf_matrix.shape}")

def word_vector(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0
    for word in tokens:
        try:
            vec += model_w2v.wv[word].reshape((1, size))
            count += 1.
        except KeyError:  # handling the case where the token is not in vocabulary
            continue
    if count != 0:
        vec /= count
    return vec



#MS2

#BOW Feature Extraction
trainingSet_bow = CountVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
bow = trainingSet_bow.fit_transform(tweets_df['clean_tweet'])
trainingSet_bow = bow[:31962,:] 
testingSet_bow = bow[31962:,:] 
xtrainingSet_bow, xvalid_bow, ytrain, yvalid = train_test_split(trainingSet_bow, train['label'], random_state=42, test_size=0.3)
print(bow.shape)



#TF-IDF Feature Extraction
tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(tweets_df['clean_tweet'])
train_tfidf = tfidf_matrix[:31962,:]
test_tfidf = tfidf_matrix[31962:,:] 
print(tfidf_matrix.shape)




#Word2Vec Feature Extraction
tokenized_tweet = tweets_df['clean_tweet'].apply(lambda x: x.split()) # tokenizing 
model_w2v = gensim.models.Word2Vec(
            tokenized_tweet,
            vector_size=200, # desired no. of features/independent variables
            window=5, # context window size
            min_count=2, # Ignores all words with total frequency lower than 2.                                  
            sg = 1, # 1 for skip-gram model
            hs = 0,
            negative = 10, # for negative sampling
            workers= 32, # no.of cores
            seed = 34
) 
model_w2v.train(tokenized_tweet, total_examples= len(tweets_df['clean_tweet']), epochs=20)
wordvec_arrays = np.zeros((len(tokenized_tweet), 200)) 
for i in range(len(tokenized_tweet)):
    wordvec_arrays[i,:] = word_vector(tokenized_tweet[i], 200)
wordvec_df = pd.DataFrame(wordvec_arrays)
train_w2v = wordvec_df.iloc[:31962,:]
test_w2v = wordvec_df.iloc[31962:,:]
print(wordvec_df.shape)
print(model_w2v.wv.most_similar(positive="dinner"))

# print(model_w2v.wv['dinner'])





lreg = LogisticRegression(solver='lbfgs') 

# #BOW with Logistic regression
lreg.fit(xtrainingSet_bow, ytrain) 
prediction = lreg.predict_proba(xvalid_bow) 
prediction_int = prediction[:,1] >= 0.3  
prediction_int = prediction_int.astype(np.int_) 
print("F1 Score for Logistic Regression with BOW Features")
print(f1_score(yvalid, prediction_int)) # calculating f1 score for the validation set



# test_pred = lreg.predict_proba(testingSet_bow)
# test_pred_int = test_pred[:,1] >= 0.3
# test_pred_int = test_pred_int.astype(np.int_)
# test['label'] = test_pred_int
# submission = test[['id','label']]
# submission.to_csv('sub_lreg_bow.csv', index=False) # writing data to a CSV file

#TF-IDF with Logistic regression

xtrain_tfidf = train_tfidf[ytrain.index]
xvalid_tfidf = train_tfidf[yvalid.index]
lreg.fit(xtrain_tfidf, ytrain) 
prediction = lreg.predict_proba(xvalid_tfidf)
prediction_int = prediction[:,1] >= 0.3
prediction_int = prediction_int.astype(np.int_) 
print(f1_score(yvalid, prediction_int) )


#Word2Vec with Logistic regression

xtrain_w2v = train_w2v.iloc[ytrain.index,:]
xvalid_w2v = train_w2v.iloc[yvalid.index,:]
lreg.fit(xtrain_w2v, ytrain) 
prediction = lreg.predict_proba(xvalid_w2v)
prediction_int = prediction[:,1] >= 0.3
prediction_int = prediction_int.astype(np.int_)
print(f1_score(yvalid, prediction_int))


#BOW with Support Vecotr Machine Model
svc = svm.SVC(kernel='linear', C=1, probability=True).fit(xtrainingSet_bow, ytrain) 
prediction = svc.predict_proba(xvalid_bow) 
prediction_int = prediction[:,1] >= 0.3 
prediction_int = prediction_int.astype(np.int_) 
print(f1_score(yvalid, prediction_int))


#TF-IDF with Support Vecotr Machine Model
svc = svm.SVC(kernel='linear', C=1, probability=True).fit(xtrain_tfidf, ytrain) 
prediction = svc.predict_proba(xvalid_tfidf) 
prediction_int = prediction[:,1] >= 0.3 
prediction_int = prediction_int.astype(np.int_) 
print(f1_score(yvalid, prediction_int))


#Word2Vec with Support Vecotr Machine Model
svc = svm.SVC(kernel='linear', C=1, probability=True).fit(xtrain_w2v, ytrain) 
prediction = svc.predict_proba(xvalid_w2v) 
prediction_int = prediction[:,1] >= 0.3 
prediction_int = prediction_int.astype(np.int_) 
print(f1_score(yvalid, prediction_int))



#BOW with XGboost
# xgb_model = xgb.XGBClassifier(max_depth=6, n_estimators=1000).fit(xtrainingSet_bow, ytrain)
# prediction = xgb_model.predict(xvalid_bow)
# print(f1_score(yvalid, prediction))


#TF-IDF with XGboost
# xgb = xgb.XGBClassifier(max_depth=6, n_estimators=1000).fit(xtrain_tfidf, ytrain) 
# prediction = xgb.predict(xvalid_tfidf)
# print(f1_score(yvalid, prediction))


#Word2Vec with XGboost
# xgb = XGBClassifier(max_depth=6, n_estimators=1000, nthread= 3).fit(xtrain_w2v, ytrain) 
# prediction = xgb.predict(xvalid_w2v)
# print(f1_score(yvalid, prediction))

# print(dir(xgb))


#Fine Tuning
matrixTrain = xgb.DMatrix(xtrain_w2v, label=ytrain) 
dvalid = xgb.DMatrix(xvalid_w2v, label=yvalid) 
dtest = xgb.DMatrix(test_w2v)
# Parameters that we are going to tune 
params = {
    'objective':'binary:logistic',
    'max_depth':6,
    'min_child_weight': 1,
    'eta':.3,
    'subsample': 1,
    'colsample_bytree': 1
 }

def custom_eval(preds, matrixTrain):
    labels = matrixTrain.get_label().astype(np.int_)
    preds = (preds >= 0.3).astype(np.int_)
    return [('f1_score', f1_score(labels, preds))]



gridsearch_params = [
    (max_depth, min_child_weight)
    for max_depth in range(6,10)
    for min_child_weight in range(5,8)
    ]

max_f1 = 0. # initializing with 0 

chosenParams = None 

for max_depth, min_child_weight in gridsearch_params:
    print("CV with max_depth={}, min_child_weight={}".format(max_depth,min_child_weight))
    
     # Update our parameters
    params['max_depth'] = max_depth
    params['min_child_weight'] = min_child_weight

     # Cross-validation
    result = xgb.cv(
        params,
        matrixTrain,
        feval= custom_eval,
        num_boost_round=200,
        maximize=True,
        seed=16,
        nfold=5,
        early_stopping_rounds=10
        )     
    
    
# # Finding best F1 Score    
mean = result['test-f1_score-mean'].max()
round = result['test-f1_score-mean'].idxmax()    
print("\tF1 Score {} for {} rounds".format(mean, round))    

if mean > max_f1:
        max_f1 = mean
        chosenParams = (max_depth,min_child_weight) 

print("Best params: {}, {}, F1 Score: {}".format(chosenParams[0], chosenParams[1], max_f1))


params['max_depth'] = 9 
params['min_child_weight'] = 7


gridsearch_params = [
    (subsample, colsample)
    for subsample in [i/10. for i in range(5,10)]
    for colsample in [i/10. for i in range(5,10)]
]

max_f1 = 0. 
chosenParams = None 

for subsample, colsample in gridsearch_params:
    print("CV with subsample={}, colsample={}".format(subsample,colsample))
    
#     # Update our parameters
    params['colsample'] = colsample
    params['subsample'] = subsample
    
    result = xgb.cv(
        params,
        matrixTrain,
        feval= custom_eval,
        num_boost_round=200,
        maximize=True,
        seed=16,
        nfold=5,
        early_stopping_rounds=10
        )
    
    # Finding best F1 Score
    mean = result['test-f1_score-mean'].max()
    round = result['test-f1_score-mean'].idxmax()
    print("\tF1 Score {} for {} rounds".format(mean, round))
    
    if mean > max_f1:
        max_f1 = mean
        chosenParams = (subsample, colsample) 

print("Best params: {}, {}, F1 Score: {}".format(chosenParams[0], chosenParams[1], max))


params['subsample'] = 0.9
params['colsample_bytree'] = 0.5


max_f1 = 0. 
chosenParams = None 
for eta in [.3, .2, .1, .05, .01, .005]:
    print("CV with eta={}".format(eta))
     # Update ETA
    params['eta'] = eta

     # Run CV
    result = xgb.cv(
        params,
        matrixTrain,
        feval= custom_eval,
        num_boost_round=1000,
        maximize=True,
        seed=16,
        nfold=5,
        early_stopping_rounds=20
    )

#     # Finding best F1 Score
    mean = result['test-f1_score-mean'].max()
    round = result['test-f1_score-mean'].idxmax()
    print("\tF1 Score {} for {} rounds".format(mean, round))
    
    if mean > max_f1:
        max_f1 = mean
        chosenParams = eta 
        
print("params: {}, F1 Score: {}".format(chosenParams, max_f1))



#Tuned Params
input = {
    'colsample': 0.9,
    'colsample_bytree': 0.5,
    'eta': 0.1,
    'max_depth': 9,
    'min_child_weight': 7,
    'objective': 'binary:logistic',
    'subsample': 0.9
}


xgb_model = xgb.train(
    input,
    matrixTrain,
    feval= custom_eval,
    num_boost_round= 1000,
    maximize=True,
    evals=[(dvalid, "Validation")],
    early_stopping_rounds=10
 )


test_pred = xgb_model.predict(dtest)
test['label'] = (test_pred >= 0.3).astype(np.int_)
submission = test[['id','label']] 
submission.to_csv('w2vXGBoostFineTuned.csv', index=False)

